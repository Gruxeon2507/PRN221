﻿namespace BusinessObject
{
    public class Class1
    {

    }
}
